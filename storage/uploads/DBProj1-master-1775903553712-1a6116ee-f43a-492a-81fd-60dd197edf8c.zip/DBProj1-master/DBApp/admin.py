from django.contrib import admin
from DBApp.models import Student

# Register your models here.
admin.site.register(Student)
