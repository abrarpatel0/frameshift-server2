from django.shortcuts import render ,redirect,get_object_or_404
from .models import Student
from .forms import StudentForm
# Create your views here.

def student_list(request):
	students= Student.objects.all() #queryset #select * from Student
	return render(request,'student_list.html',{'students':students})


def student_create(request):
	if request.method =='POST':
		name= request.POST.get('name')
		email= request.POST.get('email')
		age= request.POST.get('age')
		joined_date=request.POST.get('joined_date')
		d= Student.objects.create(
		name=name,
		email=email,
		age=age,
		joined_date=joined_date)
		d.save()
		return redirect(student_list)
	else:
		return render(request,'student_form.html')

def student_update(request,id):
	student =get_object_or_404(Student,id=id)
	if request.method=='POST':
		student.name= request.POST.get('name')
		student.email=request.POST.get('email')
		student.age= request.POST.get('age')
		student.joined_date=request.POST.get('joined_date')
		student.save()
		return redirect(student_list)
	else:
		return render(request,'student_form.html',{'student':student})
def student_delete(request,id):

	student =get_object_or_404(Student,id=id)
	#st= Student.objects.get(id=id) #id=8
	student.delete()
	return redirect(student_list)


def create(request):
	form =StudentForm()
	return render(request,'create.html',{'form':form})


	




	




	